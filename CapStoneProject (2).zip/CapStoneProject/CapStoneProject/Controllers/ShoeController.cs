﻿using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using CapStoneProject.Models.Shoe;
using CapStoneProject.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;

namespace CapStoneProject.Controllers
{
    public class ShoeController : Controller
    {

        private readonly IShoeRepository _shoeRepository;

        private readonly IHttpContextAccessor _httpContextAccessor;


        public ShoeController(IShoeRepository shoeRepository, IHttpContextAccessor httpContextAccessor)
        {
            _shoeRepository = shoeRepository;
            _httpContextAccessor = httpContextAccessor;
        }
        public async Task<IActionResult> DisplayShoes()
        {
            var model = new DisplayShoesViewModel();
            var shoesDBO = await _shoeRepository.SelectAllShoes();
            model.Shoes = shoesDBO.Select(shoeDBO => shoeDBO).ToList();

            return View(model);
            
        }

        public async Task<IActionResult> ShowShoeDetails(int id)
        {
            var model = await _shoeRepository.ShowShoeData(id);

            return View(model);

        }


        // The below methods are attempts to figure out a way to submit quantity to SQL in the same string as the other order DB stuff. It is not going well.
        // Scrap below methods and force users to order from details page?
        public async Task<IActionResult> OrderShoe(int id)
        {
            var orderShoe = new OrderShoeViewModel(id, 0);

            return View(orderShoe);
        }

        public async Task<IActionResult> OrderedShoe(OrderShoeViewModel model)
        {
            
        }

        




        //Run Identity table big block of code James provided to get system ready for user login/registration (Log off does not work)

        //Shopping cart needs to live in database; insert into method needs to be created. Cannot currently pull user's information, nor can I find a way to solve for quantity.
    }
}
