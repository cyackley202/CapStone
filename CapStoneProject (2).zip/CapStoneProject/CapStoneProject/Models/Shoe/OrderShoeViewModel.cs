﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CapStoneProject.Models.Shoe
{
    public class OrderShoeViewModel
    {
        public int ID { get; set; }
        public int Quantity { get; set; }

        public OrderShoeViewModel(int id, int quantity)
        {
            ID = id;
            Quantity = quantity;
        }
    }
}
