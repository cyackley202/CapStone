﻿using Microsoft.CodeAnalysis.CSharp.Syntax;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CapStoneProject.Models.Shoe
{
    public class DisplayShoesViewModel
    {
        public IEnumerable<ShoeDBO> Shoes { get; set; }


    }

}
