﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CapStoneProject.Models.Shoe
{
    public class ShowShoeDetailsViewModel
    {
        public string Name { get; set; }
        public string Style { get; set; }
        public double Size { get; set; }
        public string Color { get; set; }
        public double Price { get; set; }
        public int ID { get; set; }

        public ShowShoeDetailsViewModel(string name, string style, double size, string color, double price, int id)
        {
            Name = name;
            Style = style;
            Size = size;
            Color = color;
            Price = price;
            ID = id;
        }
    }
}
