﻿using CapStoneProject.Models.Shoe;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CapStoneProject.Services
{
    public interface IShoeRepository
    {
        Task<IEnumerable<ShoeDBO>> SelectAllShoes();

        Task<ShowShoeDetailsViewModel> ShowShoeData(int id);

        Task<ShoeDBO> AddToSQLCart(int id);
    }
}
