﻿using CapStoneProject.Models.Shoe;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data.SqlClient;
using Dapper;
using Microsoft.Extensions.Options;
using Identity.Dapper.Models;
using Microsoft.AspNetCore.Http;
using System.Web.Providers.Entities;
using Microsoft.AspNetCore.Identity;

namespace CapStoneProject.Services
{
    public class ShoeRepository : IShoeRepository
    {

        private string _connectionString;

        public ShoeRepository(IOptions<ConnectionProviderOptions> config)
        {
            _connectionString = config.Value.ConnectionString;
        }


        public async Task<IEnumerable<ShoeDBO>> SelectAllShoes()
        {
            const string queryString = "Select * from [dbo].ShoeCatalog";

            using (var connection = new SqlConnection(_connectionString))
            {
                IEnumerable<ShoeDBO> orderDetail = await connection.QueryAsync<ShoeDBO>(queryString);

                return orderDetail;
            }

        }

        public async Task<ShowShoeDetailsViewModel> ShowShoeData(int id)
        {
            

           var queryString = @$"Select * from [dbo].ShoeCatalog
                                         Where ID = {id}";

            using (var connection = new SqlConnection(_connectionString))
            {
                IEnumerable<ShoeDBO> orderDetail = await connection.QueryAsync<ShoeDBO>(queryString);

                var shoeToShow = orderDetail.Select(shoeDBO => shoeDBO).FirstOrDefault();

                ShowShoeDetailsViewModel coolShoes = new ShowShoeDetailsViewModel(shoeToShow.Name, shoeToShow.Style, shoeToShow.Size, shoeToShow.Color, shoeToShow.Price, shoeToShow.ID);

                return coolShoes;
            }
        }

        public async Task<ShoeDBO> AddToSQLCart(int id)
        {


            var queryString = @$"Select * from [dbo].ShoeCatalog
                                         Where ID = {id}";

            
                                         

            using (var connection = new SqlConnection(_connectionString))
            {
                IEnumerable<ShoeDBO> orderDetail = await connection.QueryAsync<ShoeDBO>(queryString);

                var shoeDbo = orderDetail.Select(shoeDBO => shoeDBO).FirstOrDefault();

                //Order Id (don't need; auto incrementing PK), UserId, ShoeID, quantity, price

                //Currently, there does not seem to be a way to get the currently logged in user's information to store and send to SQL.

                var userquery = @$"Select * from [dbo].ShoeCatalog
                                         Where Email = {????}";



                var queryStringTwo = @$"INSERT INTO [dbo].ShoppingCart(Price, ShoeID)
                                    VALUES ({shoeDbo.Price}, {shoeDbo.ID})";

            }
        }

    }
}
